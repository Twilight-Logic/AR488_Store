#!/usr/bin/python3

import sys

infilepath = ""
outfilepath = ""
hexline = ""
hexbytes = ""
byteval = 0;
flag = 0
chunkcnt = 0
bytecnt = 0
bytestotal = 0
ba = bytearray()

# This can be varied. Default is 255, but up to 8k is possible.
# Be aware of Tektronix memory constraints
chunksize = 255

if len(sys.argv) == 2:
  infilepath = sys.argv[1]

if len(sys.argv) == 3:
  infilepath = sys.argv[1]
  outfilepath = sys.argv[2]

if (infilepath == ""):
    infilepath = input("Input filename: ")
    infilepath = input("Output filename: ")

chunkreq = input("Required chunk size: ")
if (chunkreq) :
    if (int(chunkreq) > 0) : chunksize = int(chunkreq)
print("Chunk size = " + str(chunksize))

if (outfilepath != "" ):
    fgoutfile = open (outfilepath, 'wb')
else:
    print("Output file is required!")
    quit()

with open(infilepath, 'rb') as fginfile:

    byteval = fginfile.read(1)

    while byteval:

#        print(byteval)

        if (byteval == b'\x80') :
#            print("Final chunk!")
            chunkcnt += 1
            print("Chunk: ",chunkcnt)
            headerbyte1 = 0x40 | (bytecnt&0x1F00)>>8
            headerbyte2 = bytecnt&0x00FF
            fgoutfile.write(bytes([headerbyte1]))
            fgoutfile.write(bytes([headerbyte2]))
            fgoutfile.write(ba)
            fgoutfile.write(b'\x68')
            fgoutfile.write(b'\x40\x05\x7C\x45\x4F\x47\x7C\x68')
            ba.clear()
            bytecnt = 0
        else :
            ba.extend(byteval)
            bytecnt += 1;
            bytestotal += 1

        if (bytecnt == chunksize) :
            chunkcnt += 1
            print("Chunk: ",chunkcnt)
            headerbyte1 = 0x40 | (bytecnt&0x1F00)>>8
            headerbyte2 = bytecnt&0x00FF
            fgoutfile.write(bytes([headerbyte1]))
            fgoutfile.write(bytes([headerbyte2]))
            fgoutfile.write(ba)
            fgoutfile.write(b'\x68')
            ba.clear()
            bytecnt = 0

        byteval = fginfile.read(1)

    print(str(bytestotal) + " bytes written.")

    fgoutfile.close()
    fginfile.close()

